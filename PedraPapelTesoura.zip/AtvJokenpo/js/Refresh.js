//comando recarregador de pagina
function Refresh() {
    window.location.reload();
  }