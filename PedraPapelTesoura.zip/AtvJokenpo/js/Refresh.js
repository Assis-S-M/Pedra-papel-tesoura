//função de recarregamento de janela (nova partida)
function Refresh() {
    window.location.reload();
  }