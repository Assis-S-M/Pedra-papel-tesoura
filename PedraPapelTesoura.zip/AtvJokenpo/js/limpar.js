function limpar() {
    if (numJogadas > 0) {
    numJogadas--;
      if (numJogadas > 0) {
      document.getElementById('textoJogador').innerHTML = "Você jogou: ";
      document.getElementById('textoComputador').innerHTML = "Computador jogou: ";
      document.getElementById('mostrarInimigo').innerHTML = "";
      document.getElementById('mostrarJogador').innerHTML = "";
      }else{}
    }
}