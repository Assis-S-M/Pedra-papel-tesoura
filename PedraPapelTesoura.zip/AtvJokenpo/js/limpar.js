function limpar() {
   
   //logica de diminuição de turnos e limpagem de imagens somente ate os turnos de 10 a 0
    if (numJogadas > 0) {
    numJogadas--;
      if (numJogadas > 0) {
        
      //textos apresentados junto as imagens do que o player e o computador jogaram
      document.getElementById('textoJogador').innerHTML = "Você jogou: ";
      document.getElementById('textoComputador').innerHTML = "Computador jogou: ";
      
      //limpagem da imagem anterior para colocação da nova, colocando o valor do span como uma string vazia
      document.getElementById('mostrarInimigo').innerHTML = "";
      document.getElementById('mostrarJogador').innerHTML = "";
      }else{}
    }
}