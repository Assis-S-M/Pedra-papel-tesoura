//Quadro de variaveis globais
var numJogadas = 10;
var pontosJogador = 0;
var pontosInimigo = 0;

//Quadro de funções globais
limpar();
escolhaPedra();
escolhaPapel();
escolhaTesoura();
calculoResultado();
Refresh();