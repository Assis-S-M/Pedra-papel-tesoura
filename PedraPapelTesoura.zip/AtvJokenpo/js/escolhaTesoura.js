function escolhaTesoura() {
    if (numJogadas > 0) {
        var resultado = Math.floor(Math.random() * 3 + 1);
        img = document.createElement('IMG');
        img.setAttribute('src', 'imagens/Scissors.png');
        document.getElementById("mostrarJogador").appendChild(img);
        
        if (resultado == 1) {
            var img = document.createElement('IMG');
            img.setAttribute('src', 'imagens/Rock.png');
            document.getElementById("mostrarInimigo").appendChild(img);
            document.getElementById('game-result').innerHTML = "Derrota";

        } else if (resultado == 2) {
            var img = document.createElement('IMG');
            img.setAttribute('src', 'imagens/Paper.png');
            document.getElementById("mostrarInimigo").appendChild(img);
            document.getElementById('game-result').innerHTML = "Vitoria";
            
        } else if (resultado == 3) {
            var img = document.createElement('IMG');
            img.setAttribute('src', 'imagens/Scissors.png');
            document.getElementById("mostrarInimigo").appendChild(img);
            document.getElementById('game-result').innerHTML = "Empate";
        } else {}
    }
}