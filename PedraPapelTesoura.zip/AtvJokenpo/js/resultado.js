function calculoResultado(){
  //calculo
  var resultAnalise = document.getElementById('game-result').innerHTML;
  if (resultAnalise == "Vitoria") {
    pontosJogador++;
    document.getElementById('j-contador').innerHTML = pontosJogador;
    
  } else if (resultAnalise == "Derrota"){
    pontosInimigo++;
    document.getElementById('c-contador').innerHTML = pontosInimigo;
  } else {}
    //resultado
    if (numJogadas == 0) {
        if (pontosJogador > pontosInimigo) {
            document.getElementById('game-result').innerHTML = "Você ganhou";
        } else if (pontosJogador < pontosInimigo) {
            document.getElementById('game-result').innerHTML = "Você perdeu";
        } else if (pontosJogador == pontosInimigo) {
            document.getElementById('game-result').innerHTML = "Você empatou";
        }else {}
    }else {}
    
    document.getElementById('turnos').innerHTML = numJogadas;
        
    if (numJogadas == "0") {
    document.getElementById('novaPartida').innerHTML = "Clique no botão reload para uma nova partida";
    }else{}
}