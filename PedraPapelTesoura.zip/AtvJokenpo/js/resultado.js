function calculoResultado(){
  
  //calculo de pontuação com base no texto de resultado dado pelas funções de escolha
  var resultAnalise = document.getElementById('game-result').innerHTML;
  if (resultAnalise == "Vitoria") {
    pontosJogador++;
    document.getElementById('j-contador').innerHTML = pontosJogador;
    
  } else if (resultAnalise == "Derrota"){
    pontosInimigo++;
    document.getElementById('c-contador').innerHTML = pontosInimigo;
  } else {}
  
    //resultado final do jogo baseado na pontuação obtida nos 10 turnos
    if (numJogadas == 0) {
      
      //condição de vitoria
        if (pontosJogador > pontosInimigo) {
            document.getElementById('game-result').innerHTML = "Você ganhou";
        } /* condição de derrota */ else if (pontosJogador < pontosInimigo) {
            document.getElementById('game-result').innerHTML = "Você perdeu";
        } /* condição de empate */ else if (pontosJogador == pontosInimigo) {
            document.getElementById('game-result').innerHTML = "Você empatou";
        }else {}
    }else {}
    
    //atualizador do número de turnos restantes
    document.getElementById('turnos').innerHTML = numJogadas;
    
    //indicador de uma nova partida   
    if (numJogadas == "0") {
    document.getElementById('novaPartida').innerHTML = "Clique no botão reload para uma nova partida";
    }else{}
}