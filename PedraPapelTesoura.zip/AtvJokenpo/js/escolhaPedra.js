function escolhaPedra() {
    /* logica para limitar os turnos de 10 ate 0 */
    if (numJogadas > 0) {
      
        /* seletor aleatorio de jogadas
        do computador, resultados de 1 a
        3.
        Com 1 sendo pedra, 2 sendo
        papel, e 3 sendo tesoura */
        var resultado = Math.floor(Math.random() * 3 + 1);
        img = document.createElement('IMG');
        img.setAttribute('src', 'imagens/Rock.png');
        document.getElementById("mostrarJogador").appendChild(img);
        
        /* Criador de elemento de imagem e mostrador de resultado do jogo */
        if (resultado == 1) {
          
          /* escolha do PC: pedra */
            img = document.createElement('IMG');
            img.setAttribute('src', 'imagens/Rock.png');
            document.getElementById("mostrarInimigo").appendChild(img);
            document.getElementById('game-result').innerHTML = "Empate";

        } else if (resultado == 2) {
          
          /* escolha do PC: papel */
            var img = document.createElement('IMG');
            img.setAttribute('src', 'imagens/Paper.png');
            document.getElementById("mostrarInimigo").appendChild(img);
            document.getElementById('game-result').innerHTML = "Derrota";
            
        } else if (resultado == 3) {
          
          /* escolha do PC: tesoura */
            var img = document.createElement('IMG');
            img.setAttribute('src', 'imagens/Scissors.png');
            document.getElementById("mostrarInimigo").appendChild(img);
            document.getElementById('game-result').innerHTML = "Vitoria";
        } else {}
    }
}