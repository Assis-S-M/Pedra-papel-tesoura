//page reloader command
function Refresh() {
    window.location.reload();
  }