//Global variables table
var numJogadas = 10;
var pontosJogador = 0;
var pontosInimigo = 0;

//Global function table
limpar();
escolhaPedra();
escolhaPapel();
escolhaTesoura();
calculoResultado();
Refresh();